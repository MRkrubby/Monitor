
# QGIS Monitor Pro — Advanced (v3.0.0)

**Volledig herschreven** met uitgebreide logging en moderne UI.

## Highlights
- Slimme toolbar (alleen hoofdicoon + Start/Stop), menu met iconen
- Size-based rotatie + backups
- JSONL met rijke context (project, user, profiel, session)
- Correlation IDs voor Processing-runs
- Breadcrumb ringbuffer + dump op error
- Heartbeat (RAM/CPU), interval instelbaar
- PII/pad-scrubber (aan/uit)
- Webhook-meldingen bij fouten (optioneel)
- Diagnose → TXT en **Bundel logs → ZIP**

## Installatie
1. Pak de zip uit naar je pluginmap:
   `C:\Users\<user>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\qgis_monitor_pro`
2. Start QGIS en activeer de plugin.
3. Toolbar aanzetten via **Beeld → Werkbalken → QGIS Monitor Pro**.

## Tips
- **Instellingen…**: stel logmap, rotatie (MB/backups), JSONL, scrub, heartbeat, webhook en hooks in.
- **Start Monitor**: voer een Processing-taak uit en bekijk `qgis_full_*.log` / `qgis_errors_*.log` en (optioneel) `*.jsonl`.
- **Bundel logs → ZIP**: maakt een pakketteerbaar zip met env-info en log-tail.
